"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/dot-case@3.0.4";
exports.ids = ["vendor-chunks/dot-case@3.0.4"];
exports.modules = {

/***/ "(rsc)/./node_modules/.pnpm/dot-case@3.0.4/node_modules/dot-case/dist.es2015/index.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/.pnpm/dot-case@3.0.4/node_modules/dot-case/dist.es2015/index.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   dotCase: () => (/* binding */ dotCase)\n/* harmony export */ });\n/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ \"(rsc)/./node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs\");\n/* harmony import */ var no_case__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! no-case */ \"(rsc)/./node_modules/.pnpm/no-case@3.0.4/node_modules/no-case/dist.es2015/index.js\");\n\n\nfunction dotCase(input, options) {\n    if (options === void 0) { options = {}; }\n    return (0,no_case__WEBPACK_IMPORTED_MODULE_0__.noCase)(input, (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__assign)({ delimiter: \".\" }, options));\n}\n//# sourceMappingURL=index.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvLnBucG0vZG90LWNhc2VAMy4wLjQvbm9kZV9tb2R1bGVzL2RvdC1jYXNlL2Rpc3QuZXMyMDE1L2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFpQztBQUNBO0FBQzFCO0FBQ1AsOEJBQThCO0FBQzlCLFdBQVcsK0NBQU0sUUFBUSwrQ0FBUSxHQUFHLGdCQUFnQjtBQUNwRDtBQUNBIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXERhcnlsXFxEb2N1bWVudHNcXHByb2plY3RzXFxFaWdlbkdyYW1cXG9jci1kYXNoYm9hcmRcXG5vZGVfbW9kdWxlc1xcLnBucG1cXGRvdC1jYXNlQDMuMC40XFxub2RlX21vZHVsZXNcXGRvdC1jYXNlXFxkaXN0LmVzMjAxNVxcaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgX19hc3NpZ24gfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IG5vQ2FzZSB9IGZyb20gXCJuby1jYXNlXCI7XG5leHBvcnQgZnVuY3Rpb24gZG90Q2FzZShpbnB1dCwgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zID09PSB2b2lkIDApIHsgb3B0aW9ucyA9IHt9OyB9XG4gICAgcmV0dXJuIG5vQ2FzZShpbnB1dCwgX19hc3NpZ24oeyBkZWxpbWl0ZXI6IFwiLlwiIH0sIG9wdGlvbnMpKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOlswXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/.pnpm/dot-case@3.0.4/node_modules/dot-case/dist.es2015/index.js\n");

/***/ })

};
;